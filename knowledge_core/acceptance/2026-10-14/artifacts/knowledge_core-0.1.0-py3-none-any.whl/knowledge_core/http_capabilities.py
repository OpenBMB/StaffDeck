"""Explicit HTTP adapter for optional hosted model and parsing capabilities."""

import base64
import logging
from uuid import uuid4
from typing import Any

import httpx

from .ports import ModelConfig
logger = logging.getLogger(__name__)


class HttpCapabilities:
    def __init__(self, url: str, bearer: str):
        self.url, self.bearer = url.rstrip("/"), bearer

    def scoped(self, tenant_id: str, space_id: str, model_id: str | None = None):
        return ScopedCapabilities(self, tenant_id, space_id, model_id)


class ScopedCapabilities:
    def __init__(self, provider, tenant_id, space_id, model_id):
        self.provider = provider
        self.context = {"tenant_id": tenant_id, "space_id": space_id, "model_id": model_id}
        self.model_config = ModelConfig("hosted", model_id or "default", "")

    def call(self, operation: str, value: dict[str, Any]):
        call_id = uuid4().hex
        response = httpx.post(self.provider.url + "/" + operation,
            headers={"Authorization": "Bearer " + self.provider.bearer, "X-KM-Call-ID": call_id},
            json={**self.context, **value}, timeout=120)
        response.raise_for_status()
        logger.warning("KM_CAPABILITY_RESULT call_id=%s operation=%s model_id=%s status=%s",
                       call_id, operation, self.context["model_id"], response.status_code)
        return response.json()

    def generate_json(self, config, prompt, payload):
        return self.call("model", {"prompt": prompt, "payload": payload})

    def parse(self, filename, content):
        value = self.call("parse", {"filename": filename,
            "content_base64": base64.b64encode(content).decode()})
        return value["text"], value["file_type"]
