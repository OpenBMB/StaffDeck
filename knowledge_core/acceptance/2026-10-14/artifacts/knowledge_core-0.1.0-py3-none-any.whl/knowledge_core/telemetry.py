from contextlib import contextmanager
from typing import Any


class Span:
    def finish(self, **attributes: Any) -> None:
        pass


@contextmanager
def observed_span(*args: Any, **attributes: Any):
    yield Span()


@contextmanager
def llm_operation(*args: Any, **attributes: Any):
    yield Span()
