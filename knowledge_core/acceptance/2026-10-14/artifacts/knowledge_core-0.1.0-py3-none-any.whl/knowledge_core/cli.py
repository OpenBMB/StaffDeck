import argparse
import json
import os
from pathlib import Path

import uvicorn

from .api import create_app
from .http_publication import HttpSuggestionPublisher
from .http_capabilities import HttpCapabilities
from .identity import Principal, StaticBearerIdentity
from .migration import compare, migrate, preflight
from .ports import ModelConfig, OpenAICompatibleModel
from .runtime import Runtime


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the independent knowledge service")
    parser.add_argument(
        "--database-url", default=os.getenv("KM_DATABASE_URL", "sqlite:///knowledge.sqlite")
    )
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--read-only", action="store_true", default=os.getenv("KM_READ_ONLY") == "true")
    parser.add_argument("--identity-file", type=Path, default=None)
    parser.add_argument("--migration", choices=["preflight", "migrate", "compare"])
    parser.add_argument("--source", type=Path)
    parser.add_argument("--model-config", type=Path, default=None)
    parser.add_argument("--publisher-url", default=os.getenv("KM_PUBLISHER_URL"))
    parser.add_argument("--publisher-bearer", default=os.getenv("KM_PUBLISHER_BEARER"))
    parser.add_argument("--capabilities-url", default=os.getenv("KM_CAPABILITIES_URL"))
    parser.add_argument("--capabilities-bearer", default=os.getenv("KM_CAPABILITIES_BEARER", ""))
    args = parser.parse_args()
    if args.migration:
        if args.source is None:
            parser.error("--source is required for migration commands")
        try:
            report = (
                preflight(args.source)
                if args.migration == "preflight"
                else migrate(args.source, args.database_url)
                if args.migration == "migrate"
                else compare(args.source, args.database_url)
            )
        except ValueError as exc:
            report = {"ok": False, "errors": [str(exc)]}
        print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
        raise SystemExit(0 if report["ok"] else 1)
    identity = None
    if args.identity_file:
        entries = json.loads(args.identity_file.read_text())
        identity = StaticBearerIdentity(
            {
                token: Principal(
                    id=value["id"],
                    tenant_id=value.get("tenant_id", "local"),
                    display_name=value.get("display_name", value["id"]),
                    spaces=frozenset(value.get("spaces", [])),
                    permissions=frozenset(value.get("permissions", ["read"])),
                )
                for token, value in entries.items()
            }
        )
    model_config = (
        ModelConfig(**json.loads(args.model_config.read_text())) if args.model_config else None
    )
    uvicorn.run(
        create_app(
            Runtime(
                args.database_url,
                read_only=args.read_only,
                identity=identity,
                model_config=model_config,
                model=OpenAICompatibleModel() if model_config else None,
                capabilities=HttpCapabilities(args.capabilities_url, args.capabilities_bearer)
                if args.capabilities_url else None,
                publisher=HttpSuggestionPublisher(args.publisher_url, args.publisher_bearer)
                if args.publisher_url else None,
            )
        ),
        host=args.host,
        port=args.port,
    )


if __name__ == "__main__":
    main()
